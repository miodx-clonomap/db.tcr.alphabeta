// JScript source code
jQuery.ui.ncbipopper.prototype._oldGetPositionSettings = jQuery.ui.ncbipopper.prototype._getPositionSettings; jQuery.ui.ncbipopper.prototype._getPositionSettings = function(e, elementType, isOnOpen) { var ret = this._oldGetPositionSettings(e, elementType, isOnOpen); if (elementType == 'popper') { ret.offset = '30px -40px'; } return ret; };
